%% Detecting Oropharyngeal Carcinoma using Multispectral, Narrow-Band Imaging and Machine-Learning
% Updated pipeline incorporating neural network
% Shamik Mascharak, Brandon J. Baird, F. Christopher Holsinger
% Created May 20th, 2018
% Updated October 10th, 2018
% Finalized August 21st, 2019
%%
clear 
clc

imds = imageDatastore('NBI Neural Network','FileExtensions','.png','IncludeSubfolders',...
    true,'LabelSource','foldernames');

% 70% of patients for training, 30% for testing
[imdsTrain, imdsTest] = splitEachLabel(imds,0.7); 

nClust = 1; % 1 GMM cluster
reshaper = 3; % Set to 3 if texture values included; otherwise set to 2
% reshaper = 2; % Set to 3 if texture values included; otherwise set to 2

num_H = 0;
num_T = 0;

% Read in the training image set
for i = 1:length(imdsTrain.Files)
    currentfilename = imdsTrain.Files{i};
    currentimage = imread(currentfilename);
    stored_images{i} = currentimage;
    stored_name{i} = currentfilename;
    
    if contains(currentfilename,'-H') == 0 % i.e., if image is tumor
        t(:,i) = [1;0]; % target class is [1 0]
        t_alt(:,i) = 1;
        class_pt{i} = 'Tumor';
        num_T = num_T + 1;
    end
    if contains(currentfilename,'-H') == 1 % i.e., if image is healthy
        t(:,i) = [0;1]; % target class is [0 1]
        t_alt(:,i) = 0;
        class_pt{i} = 'Healthy';
        num_H = num_H + 1;
    end
    
    % Gather color (a,b) and texture (J) values from image
    [ab,txtr,data] = convert2lab(currentimage,0,0,1); % Set last value to 1 to include texture
%     [ab,txtr,data] = convert2lab(currentimage,0,0,0); % Set last value to 1 to include texture
    label = labclust(currentimage,data,nClust,0,0);
    [clustered,centers,spreads] = clustparam(data,label,nClust);
    x{i} = reshape([centers{:}],1,nClust*reshaper);
 
end

x = cell2mat(x')';
stored_name = stored_name';

sprintf('Done!')

%% Train the Neural Network

close all
nnet.guis.closeAllViews()

num_neurons = 3; % Shallow NN
% num_neurons = [5 5]; % 2 Hidden layers

net = patternnet(num_neurons);
% view(net) % To see schematic of NN architecture
[net, tr] = train(net,x,t); 

% Set 75% training, 25% validation, no test yet
net.divideParam.trainRatio = 75/100;
net.divideParam.valRatio = 25/100;
net.divideParam.testRatio = 0/100;

%% Test the Neural Network

clear currentfilename currentimage stored_images stored_name t t_alt class_pt x

% Read in the training image set
for i = 1:length(imdsTest.Files)
    currentfilename = imdsTest.Files{i};
    currentimage = imread(currentfilename);
    stored_images{i} = currentimage;
    stored_name{i} = currentfilename;
    
    if contains(currentfilename,'-H') == 0 % i.e., if image is tumor
        t(:,i) = [1;0]; % target class is [1 0]
        t_alt(:,i) = 1;
        class_pt{i} = 'Tumor';
        num_T = num_T + 1;
    end
    if contains(currentfilename,'-H') == 1 % i.e., if image is healthy
        t(:,i) = [0;1]; % target class is [0 1]
        t_alt(:,i) = 0;
        class_pt{i} = 'Healthy';
        num_H = num_H + 1;
    end
    
    % Gather color (a,b) and texture (J) values from image
    [ab,txtr,data] = convert2lab(currentimage,0,0,1); % Set last value to 1 to include texture
%     [ab,txtr,data] = convert2lab(currentimage,0,0,0); % Set last value to 1 to include texture
    label = labclust(currentimage,data,nClust,0,0);
    [clustered,centers,spreads] = clustparam(data,label,nClust);
    x{i} = reshape([centers{:}],1,nClust*reshaper);
 
end

x = cell2mat(x')';
stored_name = stored_name';

sprintf('Done!')

testT = t;
testY = net(x);
testIndices = vec2ind(testY);

[c cm ind per] = confusion(testT,testY); % 1st row of "per" lists FN, FP, TP, and TN rates

% Report NN performance
false_neg = per(1,1);
false_pos = per(1,2);
true_pos = per(1,3);
true_neg = per(1,4);

sensitivity = true_pos/(true_pos + false_neg);
specificity = true_neg/(true_neg + false_pos);
accuracy = (true_pos + true_neg)/(true_pos + false_pos + true_neg + false_neg);
PPV = true_pos/(true_pos + false_pos);
NPV = true_neg/(true_neg + false_neg);
performance = [sensitivity;specificity;accuracy;PPV;NPV];

% fprintf('Percentage Correct Classification   : %f%%\n', 100*(1-c));
% fprintf('Percentage Incorrect Classification : %f%%\n', 100*c);

plotroc(testT,testY)
[X_ROC,Y_ROC,~,AUC] = perfcurve(testT(1,:),testY(1,:),1);
fprintf('AUC : %f%%\n', AUC);

